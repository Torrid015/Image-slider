const right = document.querySelector(".right")
const left = document.querySelector(".left")
const slider = document.querySelector(".slider")
const image = document.querySelectorAll(".image")
const bottom = document.querySelector(".bottom")


slideNumber = 1;
const length = image.length; 

const nextslide = ()=>{
  slider.style.transform = `translateX(-${slideNumber * 300}px)`
  slideNumber++;
}

const firstslide = ()=>{
  slider.style.transform = `translateX(0px)`
  slideNumber= 1;
}

const prevslide = ()=>{
  slider.style.transform = `translateX(-${(slideNumber-1) * 300}px)`
  slideNumber--;
}

const lastslide = ()=>{
  slider.style.transform = `translateX(-${(length - 1) * 300})`
  slideNumber = length;
}

right.addEventListener("click", ()=>{
  slideNumber < length? nextslide() : firstslide();
  
})

left.addEventListener("click", ()=>{
  slideNumber > 0 ? prevslide() : lastslide();
})

for (let i = 0; i < length; i++) {
  const div = document.createElement("div");
  div.className = "menu";
  bottom.appendChild(div)
}